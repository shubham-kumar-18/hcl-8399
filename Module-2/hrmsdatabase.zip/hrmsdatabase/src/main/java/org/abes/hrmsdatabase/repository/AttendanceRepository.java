
package org.abes.hrmsdatabase.repository;

import org.abes.hrmsdatabase.Model.Attendance;
import org.abes.hrmsdatabase.Model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

public interface AttendanceRepository
        extends JpaRepository<Attendance, Long> {

    boolean existsByEmployeeAndAttendancedate(
            Employee employee,
            LocalDate attendancedate
    );
}
