
package org.abes.hrmsdatabase.service;

import org.abes.hrmsdatabase.Model.Attendance;
import org.abes.hrmsdatabase.repository.AttendanceRepository;
import org.abes.hrmsdatabase.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class AttendanceService {
    @Autowired
    private final AttendanceRepository attendanceRepository;
    @Autowired
    private final EmployeeRepository employeeRepository;

    public AttendanceService(
            AttendanceRepository attendanceRepository,
            EmployeeRepository employeeRepository) {
        this.attendanceRepository = attendanceRepository;
        this.employeeRepository = employeeRepository;
    }

    public String markAttendance(Attendance attendance) {

        if (attendance == null
                || attendance.getEmployee() == null
                || attendance.getAttendancedate() == null) {
            return "Employee and attendance date are required";
        }

        Long empId = attendance.getEmployee().getEmp_id();

        if (!employeeRepository.existsById(empId)) {
            return "Employee not found";
        }

        if (attendanceRepository
                .existsByEmployeeAndAttendancedate(attendance.getEmployee(), attendance.getAttendancedate())) {
            return "Attendance already marked for this employee on this date";
        }

        attendanceRepository.save(attendance);

        return "Attendance marked successfully";
    }
}
